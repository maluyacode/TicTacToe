﻿Public Class Form1
    Dim turn As Integer = 1
    Dim take As Integer = 1
    Public name1 As String = Form2.txtPlayer1.Text
    Public name2 As String = Form2.txtPlayer2.Text
    Public player1 As String

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GroupBox1.Text = name1
        GroupBox2.Text = name2
        first()
    End Sub

    Private Sub first()
        If take Mod 2 = 0 Then
            MessageBox.Show(name2 & ", It's your turn!", "", MessageBoxButtons.OK)
            player1 = "O"
            Label3.Text = "Currently using 0"
            Label4.Text = "Currently using X"
        Else
            MessageBox.Show(name1 & ", It's your turn!", "", MessageBoxButtons.OK)
            player1 = "X"
            Label3.Text = "Currently using X"
            Label4.Text = "Currently using O"
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click, Button2.Click, Button3.Click, Button4.Click, Button5.Click, Button6.Click, Button7.Click, Button8.Click, Button9.Click
        If turn = 1 Then
            GetX(sender)
        ElseIf turn = 2 Then
            GetO(sender)
        ElseIf turn = 3 Then
            GetX(sender)
        ElseIf turn = 4 Then
            GetO(sender)
        ElseIf turn = 5 Then
            GetX(sender)
        ElseIf turn = 6 Then
            GetO(sender)
        ElseIf turn = 7 Then
            GetX(sender)
        ElseIf turn = 8 Then
            GetO(sender)
        ElseIf turn = 9 Then
            GetX(sender)
        End If
        turn += 1
    End Sub

    Private Sub GetX(sender As Object)
        If sender Is Button1 Then
            Button1.Enabled = False
            Button1.Text = "X"
        ElseIf sender Is Button2 Then
            Button2.Enabled = False
            Button2.Text = "X"
        ElseIf sender Is Button3 Then
            Button3.Enabled = False
            Button3.Text = "X"
        ElseIf sender Is Button4 Then
            Button4.Enabled = False
            Button4.Text = "X"
        ElseIf sender Is Button5 Then
            Button5.Enabled = False
            Button5.Text = "X"
        ElseIf sender Is Button6 Then
            Button6.Enabled = False
            Button6.Text = "X"
        ElseIf sender Is Button7 Then
            Button7.Enabled = False
            Button7.Text = "X"
        ElseIf sender Is Button8 Then
            Button8.Enabled = False
            Button8.Text = "X"
        ElseIf sender Is Button9 Then
            Button9.Enabled = False
            Button9.Text = "X"
        End If
        Winning()
    End Sub

    Private Sub GetO(sender As Object)
        If sender Is Button1 Then
            Button1.Enabled = False
            Button1.Text = "O"
        ElseIf sender Is Button2 Then
            Button2.Enabled = False
            Button2.Text = "O"
        ElseIf sender Is Button3 Then
            Button3.Enabled = False
            Button3.Text = "O"
        ElseIf sender Is Button4 Then
            Button4.Enabled = False
            Button4.Text = "O"
        ElseIf sender Is Button5 Then
            Button5.Enabled = False
            Button5.Text = "O"
        ElseIf sender Is Button6 Then
            Button6.Enabled = False
            Button6.Text = "O"
        ElseIf sender Is Button7 Then
            Button7.Enabled = False
            Button7.Text = "O"
        ElseIf sender Is Button8 Then
            Button8.Enabled = False
            Button8.Text = "O"
        ElseIf sender Is Button9 Then
            Button9.Enabled = False
            Button9.Text = "O"
        End If
        Winning()
    End Sub

    Private Sub Winning()

        If Button1.Text = "X" And Button2.Text = "X" And Button3.Text = "X" Then
            WhoWinsX()
        ElseIf Button1.Text = "O" And Button2.Text = "O" And Button3.Text = "O" Then
            WhoWinsO()
        End If

        If Button3.Text = "X" And Button6.Text = "X" And Button9.Text = "X" Then
            WhoWinsX()
        ElseIf Button3.Text = "O" And Button6.Text = "O" And Button9.Text = "O" Then
            WhoWinsO()
        End If

        If Button7.Text = "X" And Button8.Text = "X" And Button9.Text = "X" Then
            WhoWinsX()
        ElseIf Button7.Text = "O" And Button8.Text = "O" And Button9.Text = "O" Then
            WhoWinsO()
        End If

        If Button1.Text = "X" And Button4.Text = "X" And Button7.Text = "X" Then
            WhoWinsX()
        ElseIf Button1.Text = "O" And Button4.Text = "O" And Button7.Text = "O" Then
            WhoWinsO()
        End If

        If Button1.Text = "X" And Button5.Text = "X" And Button9.Text = "X" Then
            WhoWinsX()
        ElseIf Button1.Text = "O" And Button5.Text = "O" And Button9.Text = "O" Then
            WhoWinsO()
        End If

        If Button3.Text = "X" And Button5.Text = "X" And Button7.Text = "X" Then
            WhoWinsX()
        ElseIf Button3.Text = "O" And Button5.Text = "O" And Button7.Text = "O" Then
            WhoWinsO()
        End If

        If Button4.Text = "X" And Button5.Text = "X" And Button6.Text = "X" Then
            WhoWinsX()
        ElseIf Button4.Text = "O" And Button5.Text = "O" And Button6.Text = "O" Then
            WhoWinsO()
        End If

        If ((Button1.Text = Nothing) = False) And ((Button2.Text = Nothing) = False) And ((Button3.Text = Nothing) = False) And
        ((Button4.Text = Nothing) = False) And ((Button5.Text = Nothing) = False) And ((Button6.Text = Nothing) = False) And
        ((Button7.Text = Nothing) = False) And ((Button8.Text = Nothing) = False) And ((Button9.Text = Nothing) = False) Then
            MessageBox.Show("Draw", "", MessageBoxButtons.OK)
            TextBox1.Text = Val(TextBox1.Text) + 1
            Clear()
        End If
    End Sub

    Private Sub WhoWinsX()
        If player1 = "X" Then
            MessageBox.Show(name1 & ", Wins", "", MessageBoxButtons.OK)
            txtWin1.Text = Val(txtWin1.Text) + 1
            take += 1
            turn = 0
            Clear()
            first()
            Exit Sub
        Else
            MessageBox.Show(name2 & ", Wins", "", MessageBoxButtons.OK)
            txtWin2.Text = Val(txtWin2.Text) + 1
            take += 1
            turn = 0
            Clear()
            first()
            Exit Sub
        End If

    End Sub

    Private Sub WhoWinsO()
        If player1 = "O" Then
            MessageBox.Show(name1 & ", Wins", "", MessageBoxButtons.OK)
            txtWin1.Text = Val(txtWin1.Text) + 1
            take += 1
            turn = 0
            Clear()
            first()
            Exit Sub
        Else
            MessageBox.Show(name2 & ", Wins", "", MessageBoxButtons.OK)
            txtWin2.Text = Val(txtWin2.Text) + 1
            take += 1
            turn = 0
            Clear()
            first()
            Exit Sub
        End If
    End Sub

    Private Sub Clear()
        Button1.Text = ""
        Button2.Text = ""
        Button3.Text = ""
        Button4.Text = ""
        Button5.Text = ""
        Button6.Text = ""
        Button7.Text = ""
        Button8.Text = ""
        Button9.Text = ""
        Button1.Enabled = True
        Button2.Enabled = True
        Button3.Enabled = True
        Button4.Enabled = True
        Button5.Enabled = True
        Button6.Enabled = True
        Button7.Enabled = True
        Button8.Enabled = True
        Button9.Enabled = True
    End Sub

    Private Sub BtnReset_Click(sender As Object, e As EventArgs) Handles BtnReset.Click
        TextBox1.Clear()
        txtWin1.Clear()
        txtWin2.Clear()
        Clear()
    End Sub
End Class
