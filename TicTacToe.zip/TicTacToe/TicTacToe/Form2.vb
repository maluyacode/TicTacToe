﻿Public Class Form2

    Private Sub BtnPlay_Click(sender As Object, e As EventArgs) Handles BtnPlay.Click
        If txtPlayer1.Text = "" Then
            MessageBox.Show("Please Input the name of Player 1", "Player 1")

        End If
        If txtPlayer2.Text = "" Then
            MessageBox.Show("Please Input the name of Player 2", "Player 2")
        End If

        If (txtPlayer2.Text = Nothing) = False Or (txtPlayer2.Text = Nothing) = False Then
            Me.Hide()
            Form1.Show()
        End If
    End Sub
End Class